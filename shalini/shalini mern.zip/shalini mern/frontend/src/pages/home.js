// home.js

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import "../styles/home.css";
const App = () => {
  const [projects, setProjects] = useState([]);
  const [newProject, setNewProject] = useState({ title: '', description: '' });

  useEffect(() => {
    fetchProjects();
  }, []);

  const fetchProjects = async () => {
    try {
      const response = await axios.get('http://localhost:5000/projects');
      setProjects(response.data);
    } catch (error) {
      console.error('Error fetching projects:', error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewProject({ ...newProject, [name]: value });
  };

  const addProject = async () => {
    try {
      const response = await axios.post('http://localhost:5000/projects', newProject);
      setProjects([...projects, response.data]);
      setNewProject({ title: '', description: '' });
    } catch (error) {
      console.error('Error adding project:', error);
    }
  };

  const deleteProject = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/projects/${id}`);
      setProjects(projects.filter(project => project.id !== id));
    } catch (error) {
      console.error('Error deleting project:', error);
    }
  };

  return (
    <div>
    <center>
      <h1>Team Collaboration Platform</h1>
      </center>
      <div>
        <h2>Add New Project</h2>
        <input id="one"
          type="text"
          name="title"
          placeholder="Title"
          value={newProject.title}
          onChange={handleInputChange}
        />
        
        <input id="two" 
          
          type="text "
          name="description"
          placeholder="Description"
          value={newProject.description}
          onChange={handleInputChange}
        />
        <button onClick={addProject}>Add Project</button>
      </div>
      <div>
        <h2>Projects</h2>
        <ul>
          {projects.map(project => (
            <li key={project.id}>
              <div>
                <strong>{project.title}</strong>
                <p>{project.description}</p>
              </div>
              <button onClick={() => deleteProject(project.id)}>Delete</button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default App;
